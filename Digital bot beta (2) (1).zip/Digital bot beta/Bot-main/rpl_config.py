import os
import tomllib

IS_LOADED = False


def is_loaded() -> bool:
    return IS_LOADED


def set_loaded() -> None:
    global IS_LOADED
    IS_LOADED = True


def load() -> None:
    if is_loaded():
        return

    CONFIG_LOCATION = os.environ.get("CONFIG_LOCATION", "config.toml")
    with open(CONFIG_LOCATION, "rb") as f:
        toml_dict = tomllib.load(f)
        for key, value in toml_dict.items():
            os.environ[key] = str(value)

    set_loaded()
